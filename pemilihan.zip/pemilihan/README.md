login sebagai admin : 13122001
login sebagai user menggunakan nis yang di database