<?php
session_start();
include 'functions.php';

$calon = query("SELECT * FROM calon");

if( !isset($_SESSION) ) {
  header("Location: login.php");
  exit;
} elseif( isset($_SESSION["login"]) ) {
  header("Location: admin.php");
}

include 'header.php';

?>

<a href="tambah.php" class="btn btn-primary">Tambah Data</a>
<br><br>

<table class="table table-bordered" border="1" cellpadding="10" cellspacing="0">

  <tr>
    <th>No.</th>
    <th>Nama Calon</th>
    <th>kelas</th>
    <th>jurusan</th>
    <th>Visi</th>
    <th>Misi</th>
    <!-- <th>Gambar</th> -->
  </tr>

  <?php $i = 1; ?>
  <?php foreach ($calon as $row ) : ?>

  <tr>
    <td><?= $i; ?></td>
    <!-- <td>
      <a class="btn btn-warning" href="ubah.php?id=">Ubah</a> |
      <a class="btn btn-danger" href="hapus.php?id=" onclick="return confirm('yakin?');">Hapus</a>
    </td> -->
    <td><?= $row["nama_calon"]; ?></td>
    <td><?= $row["kelas"]; ?></td>
    <td><?= $row["jurusan"]; ?></td>
    <td><?= $row["visi"]; ?></td>
    <td><?= $row["misi"]; ?></td>

  </tr>
  <?php $i++; ?>
<?php endforeach; ?>

</table>

<div class="container">
  <div class="col-md-3"></div>
  <div class="col-md-6">
    <div class="col-md-3">  
      <div class="panel panel-primary">
        <div class="panel-heading">Jarwo</div>
        <div class="panel-body">
        <?php $sql = mysqli_query($conn,"SELECT COUNT(*) as total FROM perolehan_suara WHERE no_urut = 1");
        $hasil = mysqli_fetch_assoc($sql);
        echo "$hasil[total] "; ?>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">Pajar</div>
        <div class="panel-body">
        <?php $sql = mysqli_query($conn,"SELECT COUNT(*) as total FROM perolehan_suara WHERE no_urut = 2");
        $hasil = mysqli_fetch_assoc($sql);
        echo "$hasil[total]"; ?>          
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3"></div>

</div>



<?php include 'footer.php'; ?>

<!-- <?=$row["id"]; ?>
<?=$row["id"]; ?> -->