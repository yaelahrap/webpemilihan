<?php
session_start();
include 'functions.php';

if( !isset($_SESSION["done"]) ) {
  header("Location: login.php");
  exit;
} elseif( isset($_SESSION["login-admin"]) ) {
  header ("Location: admin.php");
} elseif ($_SESSION["done"] == 1) {
  header("Location: logout.php");
}


// $alert = mysqli_query($conn, "SELECT * FROM  user WHERE id='$_POST[nama]' ");


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Pemilihan Ketua OSIS</title>

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">


  </head>
  <div class="bg-info">
  <body>
<br>
<br>
<div class="container">
  <div class="col-md-2"></div>
    <div class="col-md-8">
      <div class="alert alert-success" role="alert">
        <?php 
            if( $_SESSION["login"] ) {
              echo "Selamat Datang $_SESSION[nama] ";
            } elseif ( $_SESSION["login"] ) {
              echo "Selamat Datang $_SESSION[nama] ";
            }
        ?>
      </div>
    </div>
  <div class="col-md-2"></div>
</div>

<h2 class="text-center">Pemilihan Ketua OSIS</h2><br>
<div class="container">
  <div class="col-md-2"></div>
<?php $sql = mysqli_query($conn,"SELECT * FROM calon");
while ($r = mysqli_fetch_array($sql)) {
 ?>

    <div class="col-md-4">

      <div class="thumbnail">
        <img src="assets/img/pajar.jpg">
        <div class="caption">
          <h3 class="text-center"><?php echo "$r[nama_calon]"; ?></h3><hr>
          <h5 class="text-center"><?php echo "$r[kelas]"; ?></h5><hr>
          <h5 class="text-center"><?php echo "$r[jurusan]"; ?></h5><hr>

          <h5 class="text-center"><b>Visi</b></h5>
          <p class="text-center"><?php echo "$r[visi]"; ?></p>
          <h5 class="text-center"><b>Misi</b></h5>
          <p class="text-center"><?php echo "$r[misi]"; ?></p>
          <form  action="tambah_suara.php" method="post">
            <input type="hidden" name="no_urut" value="<?php echo "$r[id]"; ?>">
            <input type="hidden" name="id" value="<?php echo "$_SESSION[id]"; ?>">
            <center><input type="submit" name="submit_suara" class="btn btn-primary" value="Pilih" onclick="return confirm('Yakin pilih dia?');"></center>
          </form>
        </div>
      </div>

    </div>

<?php } ?>

<div class="col-md-2">

</div>




<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="assets/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="assets/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</body>
</div>
