<?php
session_start();
include 'functions.php';
if (isset($_POST["submit_suara"])) {
  $sql = mysqli_query($conn,"INSERT INTO perolehan_suara (no_urut) VALUES ('$_POST[no_urut]')");
    $sql2 =  mysqli_query($conn,"UPDATE user SET done = 1 WHERE id = '$_POST[id]' ");
    $_SESSION["done"] = 1;


    echo "
      <script>
        alert('Terimakasih atas partisipasi anda :)');
        document.location.href = 'index.php';
      </script>
    ";

}





 ?>
