<?php

$conn = mysqli_connect("localhost", "root", "", "pemilihan");


function query($query) {
  global $conn;
  $result = mysqli_query($conn, $query);
  $rows = [];
  while( $row = mysqli_fetch_assoc($result) ) {
    $rows[] = $row;
  }
  return $rows;
}

function registrasi($data) {
  global $conn;

  $nis = strtolower(stripslashes($data["nis"]));
  $nama = strtolower($data["nama"]);
  $password = mysqli_real_escape_string($conn, $data["password"]);
  $password2 = mysqli_real_escape_string($conn, $data["password2"]);

  // cek user udah ada atau belum
  $result = mysqli_query($conn, "SELECT nis FROM user WHERE
  nis = '$nis'");

  if( mysqli_fetch_assoc($result) ) {
    echo "<script>
            alert('NIS sudah terdaftar');
          </script>";
          return false;
  }

  // cek konfirmasi password
  if( $password !== $password2 ) {
    echo "<script>
            alert('konfirmasi password tidak sesuai!');
          </script>";
          return false;
  }

  // enkripsi password
  $password = password_hash($password, PASSWORD_DEFAULT);


  // tambahkan user baru ke Database
  mysqli_query($conn, "INSERT INTO user VALUES('', '$nis', '$password', '', '', '', '')");

  return mysqli_affected_rows($conn);


}

function tambah($data) {
  global $conn;

  $nama_calon = htmlspecialchars($data["nama_calon"]);
  $kelas = htmlspecialchars($data["kelas"]);
  $jurusan = htmlspecialchars($data["jurusan"]);
  $visi = htmlspecialchars($data["visi"]);
  $misi = htmlspecialchars($data["misi"]);

  // upload Gambar
  // $gambar = upload();
  // if( !$gambar ) {
  //   return false;
  // }

  $query = "INSERT INTO calon
              VALUES
              ('', '$nama_calon', '$kelas', '$jurusan', '$visi', '$misi','');
  ";
  mysqli_query($conn, $query);

  return mysqli_affected_rows($conn);
}

function hapus($id) {
  global $conn;
  mysqli_query($conn, "DELETE FROM calon WHERE id = $id");

  return mysqli_affected_rows($conn);
}

// function upload() {
//
//   $namaFile = $_FILES['gambar']['name'];
//   $ukuranFile = $_FILES['gambar']['size'];
//   $error = $_FILES['gambar']['error'];
//   $tmpName = $_FILES['gambar']['tmp_name'];
//
//   // cek apakah tidak ada gmbar yng di upload
//   if ( $error === 4 ) {
//     echo "
//       <script>
//         alert('Pilih gambar terlebih dahulu');
//       </script>";
//       return false;
//   }

  // cek apakah yg di upload adalah gambar
//   $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
//   $ekstensiGambar = explode('.', $namaFile);
//   $ekstensiGambar = strtolower(end($ekstensiGambar));
//   if ( !in_array($ekstensiGambar, $ekstensiGambarValid) ) {
//     echo "
//       <script>
//         alert('Yang anda upload bukan gambar!');
//       </script>";
//       return false;
//   }
//
//   //cek jika ukurannya terlalu besar
//   if ( $ukuranFile > 1000000 ) {
//     echo "
//       <script>
//         alert('Ukuran gambar terlalu besar!');
//       </script>";
//       return false;
//   }
//
//   // lolos pengecekan
//   move_uploaded_file($tmpName, 'assets/img/' . $namaFile);
//
//   return $namaFile;
//
//
//
// }













?>
