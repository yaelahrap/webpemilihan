<?php
session_start();

if ( isset($_SESSION["login"]) ) {
  header("Location: index.php");
} elseif( isset($_SESSION["login-admin"]) ) {
  header("Location: admin.php");
}

include 'functions.php';


if( isset($_POST["login"]) ) {

  // $nama = $_POST["nama"];
  $nis = $_POST["nis"];
  


  $result = mysqli_query($conn, "SELECT * FROM user  WHERE
  nis = '$nis'");

  // cek NIS
  if ( mysqli_num_rows($result) === 1 ) {

    // cek password
    $row = mysqli_fetch_assoc($result);

      if ($row["level"] == 1) {
        $_SESSION["login-admin"] = true;
          header("location: admin.php");
      }elseif($row["done"] == 1){
        echo "<script>
                alert('Maaf user sudah memilih!');
              </script>";

      }else{
      // set session
      $_SESSION["login"] = true;
      $_SESSION["id"] = $row["id"];
      $_SESSION["nis"] = $row["nis"];
      $_SESSION["nama"] = $row["nama"];
      $_SESSION["jk"] = $row["jk"];
      $_SESSION["done"] = $row["done"];

      header("Location: index.php");
      exit;


    }

  }

  $error = true;

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Login</title>

  <!-- Custom fonts for this template-->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-3"></div>
              <div class="col-lg-6">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Login!</h1>
                  </div>

                  <?php if( isset($error) ) : ?>
                    <p class="text-center" style="color: red; font-style: italic;">NIS Salah!!!</p>
                  <?php endif; ?>

                  <form class="user" action="" method="post">
                    <div class="form-group">
                      <input type="text" name="nis" class="form-control form-control-user" id="nis" placeholder="NIS" autofocus autocomplete="off">
                    </div>
                    <!-- <div class="form-group">
                      <input type="password" name="password" class="form-control form-control-user" id="password" placeholder="Password">
                    </div> -->
                    <button class="btn btn-primary btn-user btn-block" type="submit" name="login">
                      Login
                    </button>
                    <hr>
                    <!-- <div class="text-center">
                      <a class="small" href="register.php">Create an account!</a>
                    </div> -->
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="assets/js/sb-admin-2.min.js"></script>

</body>

</html>
